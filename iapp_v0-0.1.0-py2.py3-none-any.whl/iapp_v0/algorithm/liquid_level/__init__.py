# 液位识别
from .ab_liquid_level_reco import LiquidLevelReco

__version__ = "1.0.0"

__all__ = [
    "LiquidLevelReco"
]
